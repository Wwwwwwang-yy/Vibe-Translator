class EventEmitter {
  constructor() {
    this.listeners = {};
  }
  on(event, listener, options) {
    if (!this.listeners[event]) this.listeners[event] = new Set();
    this.listeners[event].add(listener);
    if (options?.once) {
      const wrapper = () => {
        this.un(event, wrapper);
        this.un(event, listener);
      };
      this.on(event, wrapper);
      return () => this.un(event, listener);
    }
    return () => this.un(event, listener);
  }
  un(event, listener) {
    this.listeners[event]?.delete(listener);
  }
  once(event, listener) {
    return this.on(event, listener, { once: true });
  }
  unAll() {
    this.listeners = {};
  }
  emit(event, ...args) {
    this.listeners[event]?.forEach(listener => listener(...args));
  }
}

class BasePlugin extends EventEmitter {
  constructor(options) {
    super();
    this.subscriptions = [];
    this.options = options;
  }
  onInit() {}
  _init(wavesurfer) {
    this.wavesurfer = wavesurfer;
    this.onInit();
  }
  destroy() {
    this.emit('destroy');
    this.subscriptions.forEach(sub => sub());
  }
}

function createDraggable(element, onMove, onStart, onEnd, threshold = 3, button = 0, tapThreshold = 100) {
  if (!element) return () => {};
  const isTouchDevice = matchMedia('(pointer: coarse)').matches;
  let cleanup = () => {};
  const onPointerDown = (e) => {
    if (e.button !== button) return;
    e.preventDefault();
    e.stopPropagation();
    let startX = e.clientX, startY = e.clientY;
    let isDragging = false;
    const startTime = Date.now();
    const onPointerMove = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (isTouchDevice && Date.now() - startTime < tapThreshold) return;
      const dx = e.clientX - startX, dy = e.clientY - startY;
      if (!isDragging || Math.abs(dx) > threshold || Math.abs(dy) > threshold) {
        const rect = element.getBoundingClientRect();
        const { left, top } = rect;
        if (!isDragging) {
          onStart?.(startX - left, startY - top);
          isDragging = true;
        }
        onMove(dx, dy, e.clientX - left, e.clientY - top);
        startX = e.clientX;
        startY = e.clientY;
      }
    };
    const onPointerUp = (e) => {
      if (isDragging) {
        const rect = element.getBoundingClientRect();
        const { left, top } = rect;
        onEnd?.(e.clientX - left, e.clientY - top);
      }
      cleanup();
    };
    const onPointerOut = (e) => {
      if (e.relatedTarget && e.relatedTarget !== document.documentElement) return;
      onPointerUp(e);
    };
    const onTouchMove = (e) => {
      if (isDragging) {
        e.stopPropagation();
        e.preventDefault();
      }
    };
    const onClick = (e) => {
      if (isDragging) {
        e.stopPropagation();
        e.preventDefault();
      }
    };
    document.addEventListener('pointermove', onPointerMove);
    document.addEventListener('pointerup', onPointerUp);
    document.addEventListener('pointerout', onPointerOut);
    document.addEventListener('pointercancel', onPointerOut);
    document.addEventListener('touchmove', onTouchMove, { passive: false });
    document.addEventListener('click', onClick, { capture: true });
    cleanup = () => {
      document.removeEventListener('pointermove', onPointerMove);
      document.removeEventListener('pointerup', onPointerUp);
      document.removeEventListener('pointerout', onPointerOut);
      document.removeEventListener('pointercancel', onPointerOut);
      document.removeEventListener('touchmove', onTouchMove);
      setTimeout(() => {
        document.removeEventListener('click', onClick, { capture: true });
      }, 10);
    };
  };
  element.addEventListener('pointerdown', onPointerDown);
  return () => {
    cleanup();
    element.removeEventListener('pointerdown', onPointerDown);
  };
}

function createElement(tag, props, parent) {
  const el = props.xmlns ? document.createElementNS(props.xmlns, tag) : document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === 'children') {
      for (const [childTag, childProps] of Object.entries(props)) {
        if (typeof childProps === 'string') {
          el.appendChild(document.createTextNode(childProps));
        } else {
          el.appendChild(createElement(childTag, childProps));
        }
      }
    } else if (key === 'style') {
      Object.assign(el.style, value);
    } else if (key === 'textContent') {
      el.textContent = value;
    } else {
      el.setAttribute(key, value.toString());
    }
  }
  parent?.appendChild(el);
  return el;
}

function createElementShorthand(tag, props, parent) {
  const el = createElement(tag, props || {});
  parent?.appendChild(el);
  return el;
}

class Region extends EventEmitter {
  constructor(options, totalDuration, numberOfChannels = 0) {
    super();
    this.totalDuration = totalDuration;
    this.numberOfChannels = numberOfChannels;
    this.minLength = 0;
    this.maxLength = Infinity;
    this.contentEditable = false;
    this.subscriptions = [];
    this.id = options.id || `region-${Math.random().toString(32).slice(2)}`;
    this.start = this.clampPosition(options.start);
    this.end = this.clampPosition(options.end ?? options.start);
    this.drag = options.drag ?? true;
    this.resize = options.resize ?? true;
    this.color = options.color ?? 'rgba(0, 0, 0, 0.1)';
    this.minLength = options.minLength ?? this.minLength;
    this.maxLength = options.maxLength ?? this.maxLength;
    this.channelIdx = options.channelIdx ?? -1;
    this.contentEditable = options.contentEditable ?? this.contentEditable;
    this.element = this.initElement();
    this.setContent(options.content);
    this.setPart();
    this.renderPosition();
    this.initMouseEvents();
  }
  clampPosition(pos) {
    return Math.max(0, Math.min(this.totalDuration, pos));
  }
  setPart() {
    const isMarker = this.start === this.end;
    this.element.setAttribute('part', `${isMarker ? 'marker' : 'region'} ${this.id}`);
  }
  addResizeHandles(element) {
    const handleStyle = {
      position: 'absolute', zIndex: '2', width: '6px', height: '100%',
      top: '0', cursor: 'ew-resize', wordBreak: 'keep-all'
    };
    const leftHandle = createElementShorthand('div', {
      part: 'region-handle region-handle-left',
      style: { ...handleStyle, left: '0', borderLeft: '2px solid rgba(0, 0, 0, 0.5)', borderRadius: '2px 0 0 2px' }
    }, element);
    const rightHandle = createElementShorthand('div', {
      part: 'region-handle region-handle-right',
      style: { ...handleStyle, right: '0', borderRight: '2px solid rgba(0, 0, 0, 0.5)', borderRadius: '0 2px 2px 0' }
    }, element);
    this.subscriptions.push(
      createDraggable(leftHandle, (dx) => this.onResize(dx, 'start'), null, () => this.onEndResizing(), 1),
      createDraggable(rightHandle, (dx) => this.onResize(dx, 'end'), null, () => this.onEndResizing(), 1)
    );
  }
  removeResizeHandles(element) {
    const left = element.querySelector('[part*="region-handle-left"]');
    const right = element.querySelector('[part*="region-handle-right"]');
    left && element.removeChild(left);
    right && element.removeChild(right);
  }
  initElement() {
    const isMarker = this.start === this.end;
    let top = 0, height = 100;
    if (this.channelIdx >= 0 && this.channelIdx < this.numberOfChannels) {
      height = 100 / this.numberOfChannels;
      top = height * this.channelIdx;
    }
    const el = createElementShorthand('div', {
      style: {
        position: 'absolute', top: `${top}%`, height: `${height}%`,
        backgroundColor: isMarker ? 'none' : this.color,
        borderLeft: isMarker ? '2px solid ' + this.color : 'none',
        borderRadius: '2px', boxSizing: 'border-box',
        transition: 'background-color 0.2s ease',
        cursor: this.drag ? 'grab' : 'default',
        pointerEvents: 'all'
      }
    });
    if (!isMarker && this.resize) this.addResizeHandles(el);
    return el;
  }
  renderPosition() {
    const leftPercent = (this.start / this.totalDuration) * 100;
    const rightPercent = ((this.totalDuration - this.end) / this.totalDuration) * 100;
    this.element.style.left = `${leftPercent}%`;
    this.element.style.right = `${rightPercent}%`;
  }
  toggleCursor(isDragging) {
    if (this.drag && this.element?.style) {
      this.element.style.cursor = isDragging ? 'grabbing' : 'grab';
    }
  }
  initMouseEvents() {
    const { element } = this;
    if (!element) return;
    element.addEventListener('click', (e) => this.emit('click', e));
    element.addEventListener('mouseenter', (e) => this.emit('over', e));
    element.addEventListener('mouseleave', (e) => this.emit('leave', e));
    element.addEventListener('dblclick', (e) => this.emit('dblclick', e));
    element.addEventListener('pointerdown', () => this.toggleCursor(true));
    element.addEventListener('pointerup', () => this.toggleCursor(false));
    this.subscriptions.push(
      createDraggable(element,
        (dx) => this.onMove(dx),
        () => this.toggleCursor(true),
        () => { this.toggleCursor(false); this.drag && this.emit('update-end'); }
      )
    );
    if (this.contentEditable && this.content) {
      this.content.addEventListener('click', (e) => this.onContentClick(e));
      this.content.addEventListener('blur', () => this.onContentBlur());
    }
  }
  _onUpdate(dx, edge) {
    if (!this.element.parentElement) return;
    const { width } = this.element.parentElement.getBoundingClientRect();
    const delta = (dx / width) * this.totalDuration;
    const newStart = edge !== 'end' ? this.start + delta : this.start;
    const newEnd = edge !== 'start' ? this.end + delta : this.end;
    const length = newEnd - newStart;
    if (newStart >= 0 && newEnd <= this.totalDuration && newStart <= newEnd && length >= this.minLength && length <= this.maxLength) {
      this.start = newStart;
      this.end = newEnd;
      this.renderPosition();
      this.emit('update', edge);
    }
  }
  onMove(dx) {
    this.drag && this._onUpdate(dx);
  }
  onResize(dx, edge) {
    this.resize && this._onUpdate(dx, edge);
  }
  onEndResizing() {
    this.resize && this.emit('update-end');
  }
  onContentClick(e) {
    e.stopPropagation();
    e.target.focus();
    this.emit('click', e);
  }
  onContentBlur() {
    this.emit('update-end');
  }
  _setTotalDuration(duration) {
    this.totalDuration = duration;
    this.renderPosition();
  }
  play() {
    this.emit('play');
  }
  setContent(content) {
    this.content?.remove();
    if (content) {
      if (typeof content === 'string') {
        const isMarker = this.start === this.end;
        this.content = createElementShorthand('div', {
          style: { padding: `0.2em ${isMarker ? 0.2 : 0.4}em`, display: 'inline-block' },
          textContent: content
        });
      } else {
        this.content = content;
      }
      if (this.contentEditable) this.content.contentEditable = 'true';
      this.content.setAttribute('part', 'region-content');
      this.element.appendChild(this.content);
    } else {
      this.content = undefined;
    }
  }
  setOptions(options) {
    if (options.color) {
      this.color = options.color;
      this.element.style.backgroundColor = this.color;
    }
    if (options.drag !== undefined) {
      this.drag = options.drag;
      this.element.style.cursor = this.drag ? 'grab' : 'default';
    }
    if (options.start !== undefined || options.end !== undefined) {
      const isMarker = this.start === this.end;
      this.start = this.clampPosition(options.start ?? this.start);
      this.end = this.clampPosition(options.end ?? (isMarker ? this.start : this.end));
      this.renderPosition();
      this.setPart();
    }
    if (options.content) this.setContent(options.content);
    if (options.id) {
      this.id = options.id;
      this.setPart();
    }
    if (options.resize !== undefined && options.resize !== this.resize) {
      const isMarker = this.start === this.end;
      this.resize = options.resize;
      if (this.resize && !isMarker) {
        this.addResizeHandles(this.element);
      } else {
        this.removeResizeHandles(this.element);
      }
    }
  }
  remove() {
    this.emit('remove');
    this.subscriptions.forEach(sub => sub());
    this.element.remove();
    this.element = null;
  }
}

class RegionsPlugin extends BasePlugin {
  constructor(options) {
    super(options);
    this.regions = [];
    this.regionsContainer = this.initRegionsContainer();
  }
  static create(options) {
    return new RegionsPlugin(options);
  }
  onInit() {
    if (!this.wavesurfer) throw Error('WaveSurfer is not initialized');
    this.wavesurfer.getWrapper().appendChild(this.regionsContainer);
    let activeRegions = [];
    this.subscriptions.push(
      this.wavesurfer.on('timeupdate', (currentTime) => {
        const inRegions = this.regions.filter(r => 
          r.start <= currentTime && (r.end === r.start ? r.start + 0.05 : r.end) >= currentTime
        );
        inRegions.forEach(r => {
          if (!activeRegions.includes(r)) this.emit('region-in', r);
        });
        activeRegions.forEach(r => {
          if (!inRegions.includes(r)) this.emit('region-out', r);
        });
        activeRegions = inRegions;
      })
    );
  }
  initRegionsContainer() {
    return createElementShorthand('div', {
      style: { position: 'absolute', top: '0', left: '0', width: '100%', height: '100%', zIndex: '3', pointerEvents: 'none' }
    });
  }
  getRegions() {
    return this.regions;
  }
  avoidOverlapping(region) {
    if (!region.content) return;
    setTimeout(() => {
      const contentRect = region.content.getBoundingClientRect();
      const margin = this.regions.reduce((acc, r) => {
        if (r === region || !r.content) return acc;
        const rRect = r.content.getBoundingClientRect();
        return contentRect.left < rRect.left + rRect.width && rRect.left < contentRect.left + contentRect.width ? acc + rRect.height : acc;
      }, 0);
      region.content.style.marginTop = `${margin}px`;
    }, 1);
  }
  adjustScroll(region) {
    const wrapper = this.wavesurfer?.getWrapper()?.parentElement;
    if (!wrapper) return;
    const { clientWidth, scrollWidth } = wrapper;
    if (scrollWidth <= clientWidth) return;
    const wrapperRect = wrapper.getBoundingClientRect();
    const regionRect = region.element.getBoundingClientRect();
    const left = regionRect.left - wrapperRect.left;
    const right = regionRect.right - wrapperRect.left;
    if (left < 0) wrapper.scrollLeft += left;
    else if (right > clientWidth) wrapper.scrollLeft += right - clientWidth;
  }
  virtualAppend(region, container, element) {
    const checkVisibility = () => {
      if (!this.wavesurfer) return;
      const totalWidth = this.wavesurfer.getWidth();
      const scrollLeft = this.wavesurfer.getScroll();
      const viewportWidth = container.clientWidth;
      const duration = this.wavesurfer.getDuration();
      const regionLeft = Math.round((region.start / duration) * viewportWidth);
      const regionWidth = Math.round(((region.end - region.start) / duration) * viewportWidth) || 1;
      if (regionLeft + regionWidth > scrollLeft && regionLeft < scrollLeft + totalWidth) {
        container.appendChild(element);
      } else {
        element.remove();
      }
    };
    setTimeout(() => {
      if (!this.wavesurfer) return;
      checkVisibility();
      const onScroll = this.wavesurfer.on('scroll', checkVisibility);
      this.subscriptions.push(region.once('remove', onScroll), onScroll);
    }, 0);
  }
  saveRegion(region) {
    this.virtualAppend(region, this.regionsContainer, region.element);
    this.avoidOverlapping(region);
    this.regions.push(region);
    const listeners = [
      region.on('update', (edge) => {
        if (!edge) this.adjustScroll(region);
        this.emit('region-update', region, edge);
      }),
      region.on('update-end', () => {
        this.avoidOverlapping(region);
        this.emit('region-updated', region);
      }),
      region.on('play', () => {
        this.wavesurfer?.play();
        this.wavesurfer?.setTime(region.start);
      }),
      region.on('click', (e) => this.emit('region-clicked', region, e)),
      region.on('dblclick', (e) => this.emit('region-double-clicked', region, e)),
      region.once('remove', () => {
        listeners.forEach(l => l());
        this.regions = this.regions.filter(r => r !== region);
        this.emit('region-removed', region);
      })
    ];
    this.subscriptions.push(...listeners);
    this.emit('region-created', region);
  }
  addRegion(options) {
    if (!this.wavesurfer) throw Error('WaveSurfer is not initialized');
    const duration = this.wavesurfer.getDuration();
    const channels = this.wavesurfer.getDecodedData()?.numberOfChannels;
    const region = new Region(options, duration, channels);
    if (duration) {
      this.saveRegion(region);
    } else {
      this.subscriptions.push(this.wavesurfer.once('ready', (d) => {
        region._setTotalDuration(d);
        this.saveRegion(region);
      }));
    }
    return region;
  }
  enableDragSelection(options, threshold = 3) {
    const wrapper = this.wavesurfer?.getWrapper();
    if (!(wrapper && wrapper instanceof HTMLElement)) return () => {};
    let region = null;
    let startX = 0;
    return createDraggable(wrapper,
      (dx, dy, x, y) => {
        if (!region) return;
        region._onUpdate(dx, x > startX ? 'end' : 'start');
      },
      (x) => {
        startX = x;
        if (!this.wavesurfer) return;
        const duration = this.wavesurfer.getDuration();
        const channels = this.wavesurfer.getDecodedData()?.numberOfChannels;
        const { width } = this.wavesurfer.getWrapper().getBoundingClientRect();
        const startPos = (x / width) * duration;
        const endPos = ((x + 5) / width) * duration;
        region = new Region({ ...options, start: startPos, end: endPos }, duration, channels);
        this.regionsContainer.appendChild(region.element);
      },
      () => {
        if (region) {
          this.saveRegion(region);
          region = null;
        }
      },
      threshold
    );
  }
  clearRegions() {
    this.regions.forEach(r => r.remove());
  }
  destroy() {
    this.clearRegions();
    super.destroy();
    this.regionsContainer.remove();
  }
}

window.RegionsPlugin = RegionsPlugin;